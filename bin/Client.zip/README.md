A Dark Room
=========

A Minimalist Text Adventure Game

[Chinese translation](https://github.com/Tedko/CHN-Ver-of-ADarkRoom)

[Click to play](http://adarkroom.doublespeakgames.com/)
